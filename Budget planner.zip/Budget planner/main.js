const deals = [];
function addDeal() {
 const team = prompt('Enter team name:');
 const vendor = prompt('Enter vendor name:');
 const amount = parseFloat(prompt('Enter deal amount:'));
if (!team || !vendor || isNaN(amount)) {
 alert('Invalid input. Please try again.');
 return;
}
deals.push({ team, vendor, amount });
alert('Deal added successfully!');
}
 function calculateBudget() {
 const resultContainer = document.getElementById('result');
 const totalBudget = deals.reduce((sum, deal) => sum + deal.amount, 0);
 resultContainer.textContent = `Annual Budget:
$${totalBudget.toFixed(2)}`;
}